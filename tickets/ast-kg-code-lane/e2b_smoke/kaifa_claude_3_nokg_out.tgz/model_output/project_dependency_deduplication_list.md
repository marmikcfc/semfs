# Project Dependency Deduplication List

> **Sources consulted:**
> - `/dependency-management/pom-parent.xml` — Maven parent POM
> - `/dependency-management/maven_bom_config.xml` — BOM (Bill of Materials)
> - `/project-code/pom.xml` — Main project POM
> - `/development/project-code/project_object_model.xml` — Duplicate project POM
> - `/build/build.gradle` — Gradle build file
> - `/dependency-management/dependency-audit-2025Q1.md` — Q1 2025 audit (Java/Node.js/Python)
> - `/dependency-management/npm_package_audit.json` — npm audit report

---

## Java / Spring Ecosystem

| Library / Framework | Category |
|---|---|
| Spring Boot (`spring-boot-starter-parent`) | Core Framework |
| Spring Cloud (`spring-cloud-dependencies`) | Microservices Framework |
| Spring Security (`spring-boot-starter-security`) | Security |
| Spring Data JPA (`spring-boot-starter-data-jpa`) | Data Access |
| Spring Data Redis (`spring-boot-starter-data-redis`) | Caching / Data Store |
| Spring Web (`spring-boot-starter-web`) | Web / REST API |
| Spring Cache (`spring-boot-starter-cache`) | Caching |
| Spring Validation (`spring-boot-starter-validation`) | Input Validation |
| Spring Actuator (`spring-boot-starter-actuator`) | Monitoring / Health |
| Spring Session Data Redis (`spring-session-data-redis`) | Session Management |
| Spring Security Test (`spring-security-test`) | Testing |
| Spring Boot Test (`spring-boot-starter-test`) | Testing |

---

## Data Layer

| Library / Framework | Category |
|---|---|
| Hibernate (`hibernate-core`) | ORM / Data Persistence |
| MySQL Connector (`mysql-connector-java` / `mysql-connector-j`) | Database Driver |
| PostgreSQL Driver (`postgresql`) | Database Driver |
| Flyway (`flyway-core`) | Database Migration |
| Redisson (`redisson`) | Redis Client |
| H2 Database (`h2`) | Embedded DB (Testing) |

---

## Security & Authentication

| Library / Framework | Category |
|---|---|
| JJWT API (`jjwt-api`) | JWT Authentication |
| JJWT Impl (`jjwt-impl`) | JWT Authentication |
| JJWT Jackson (`jjwt-jackson`) | JWT Authentication |
| Nimbus JOSE + JWT (`nimbus-jose-jwt`) | JWT / JOSE |
| BCrypt (`bcrypt`) | Password Hashing |

---

## Observability & Resilience

| Library / Framework | Category |
|---|---|
| Micrometer (`micrometer`) | Metrics |
| OpenTelemetry (`opentelemetry`) | Distributed Tracing |
| Resilience4j (`resilience4j`) | Circuit Breaker / Resilience |
| Logback (`logback-classic`) | Logging |

---

## Utilities (Java)

| Library / Framework | Category |
|---|---|
| Lombok (`lombok`) | Code Generation |
| Jackson (`jackson`) | JSON Serialization |
| MapStruct (`mapstruct`) | Object Mapping |
| Guava (`guava`) | General Utilities |
| Apache Commons Lang (`commons-lang3`) | General Utilities |
| SpringDoc OpenAPI (`springdoc-openapi-starter-webmvc-ui` / `springdoc-openapi-ui`) | API Documentation (Swagger) |

---

## Messaging (Java)

| Library / Framework | Category |
|---|---|
| Apache Kafka Clients (`kafka-clients`) | Message Queue |
| Spring Kafka (`spring-kafka`) | Kafka Integration |

---

## Testing (Java)

| Library / Framework | Category |
|---|---|
| Testcontainers (`testcontainers`) | Integration Testing |
| WireMock (`wiremock`) | HTTP Mock / Stub |
| Pact (`pact`) | Contract Testing |
| Gatling (`gatling`) | Performance / Load Testing |
| JUnit 5 | Unit Testing |
| JaCoCo | Code Coverage |

---

## Node.js / JavaScript

| Library / Framework | Category |
|---|---|
| Express (`express`) | Web Framework |
| Axios (`axios`) | HTTP Client |
| JSON Web Token (`jsonwebtoken`) | JWT Authentication |
| Winston (`winston`) | Logging |
| Next.js | Frontend Framework (SSR) |
| React (`react-scripts`) | Frontend Framework |
| PostCSS (`postcss`) | CSS Processing |
| semver | Version Parsing |

---

## Python

| Library / Framework | Category |
|---|---|
| FastAPI (`fastapi`) | Web Framework / REST API |
| Pydantic (`pydantic`) | Data Validation |
| SQLAlchemy (`sqlalchemy`) | ORM / Data Access |
| Celery (`celery`) | Task Queue / Async Worker |
| Redis (`redis`) | Redis Client |
| Requests (`requests`) | HTTP Client |
| HTTPX (`httpx`) | Async HTTP Client |
| pytest (`pytest`) | Testing Framework |

---

## Build & DevOps Tools

| Tool | Category |
|---|---|
| Maven (`maven-compiler-plugin`, `maven-surefire-plugin`, `spring-boot-maven-plugin`) | Build Tool |
| Gradle (`spring` plugin, `jacoco`, `checkstyle`) | Build Tool |
| Checkstyle | Code Style |
| SpotBugs | Static Analysis |
| OWASP Dependency Check | Security Scanning |
| SonarQube | Code Quality |
| Dependabot | Dependency Automation |

---

## Summary Statistics

| Ecosystem | Unique Libraries / Frameworks |
|---|---|
| Java / Spring | 32 |
| Node.js / JavaScript | 8 |
| Python | 8 |
| Build & DevOps | 7 |
| **Total (deduplicated)** | **55** |
