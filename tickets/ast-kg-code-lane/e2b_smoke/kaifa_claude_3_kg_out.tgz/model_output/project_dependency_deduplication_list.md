# Project Dependency Deduplication List

**Generated:** 2026-06-14  
**Sources:** `dependency-management/pom-parent.xml`, `project-code/pom.xml`, `build/build.gradle`, `dependency-management/requirements.txt`, `dependency-management/python_requirements_dev.txt`, `dependency-management/package.json`, `dependency-management/dependency-audit-2025Q1.md`

---

## Java / Maven / Gradle Dependencies

| Library / Artifact | Category |
|---|---|
| spring-boot-starter-parent | Framework – Spring Boot |
| spring-boot-starter-web | Framework – Spring Boot |
| spring-boot-starter-data-jpa | Framework – Spring Boot |
| spring-boot-starter-security | Framework – Spring Boot |
| spring-boot-starter-validation | Framework – Spring Boot |
| spring-boot-starter-data-redis | Framework – Spring Boot |
| spring-boot-starter-cache | Framework – Spring Boot |
| spring-boot-starter-actuator | Framework – Spring Boot |
| spring-boot-starter-test | Framework – Spring Boot |
| spring-cloud-dependencies | Framework – Spring Cloud |
| spring-security-test | Testing – Spring Security |
| spring-session-data-redis | Session Management |
| hibernate-core | ORM – Data Layer |
| mysql-connector-java / mysql-connector-j | Database Driver |
| postgresql | Database Driver |
| flyway-core | Database Migration |
| redisson | Redis Client |
| jjwt-api | Authentication – JWT |
| jjwt-impl | Authentication – JWT |
| jjwt-jackson | Authentication – JWT |
| springdoc-openapi-starter-webmvc-ui / springdoc-openapi-ui | API Documentation |
| lombok | Code Generation |
| commons-lang3 | Utility – Apache Commons |
| h2 | Database – Testing |
| jacoco | Test Coverage |
| checkstyle | Code Quality |
| maven-enforcer-plugin | Build Quality |
| maven-compiler-plugin | Build Tool |
| maven-surefire-plugin | Build Tool |

---

## Python Dependencies

| Library | Category |
|---|---|
| requests | HTTP Client |
| httpx | HTTP Client |
| urllib3 | HTTP Client |
| fastapi | Web Framework |
| pydantic | Data Validation |
| SQLAlchemy | ORM – Data Layer |
| alembic | Database Migration |
| PyMySQL | Database Driver |
| psycopg2-binary | Database Driver |
| celery | Task Queue |
| redis | Redis Client |
| pandas | Data Analysis |
| numpy | Data Analysis |
| matplotlib | Data Visualization |
| seaborn | Data Visualization |
| scipy | Scientific Computing |
| jupyter | Notebook Environment |
| jupyterlab | Notebook Environment |
| ipykernel | Notebook Environment |
| locust | Performance Testing |
| pytest | Testing Framework |
| pytest-asyncio | Testing Framework |
| pytest-cov | Test Coverage |
| pytest-mock | Testing – Mocking |
| responses | Testing – HTTP Mocking |
| click | CLI Utility |
| rich | CLI Utility |
| python-dotenv | Configuration |
| pyyaml | Configuration |
| jinja2 | Templating |
| black | Code Quality |
| ruff | Code Quality |
| flake8 | Code Quality |
| mypy | Type Checking |
| pre-commit | Code Quality |
| openpyxl | Report Generation |
| reportlab | Report Generation |

---

## Node.js / npm Dependencies

| Library | Category |
|---|---|
| express | Web Framework |
| axios | HTTP Client |
| axios-mock-adapter | Testing – HTTP Mocking |
| jsonwebtoken | Authentication – JWT |
| winston | Logging |
| typescript | Language |
| jest | Testing Framework |
| ts-jest | Testing Framework |
| eslint | Code Quality |
| @typescript-eslint/parser | Code Quality |
| @typescript-eslint/eslint-plugin | Code Quality |
| prettier | Code Formatting |
| @types/node | Type Definitions |
| @types/jest | Type Definitions |
| next.js (Next.js) | Frontend Framework |
| react-scripts | Frontend Build Tool |
| postcss | CSS Processing |

---

## Summary

| Ecosystem | Unique Libraries |
|---|---|
| Java (Maven / Gradle) | 29 |
| Python (pip) | 37 |
| Node.js (npm) | 17 |
| **Total (deduplicated across all ecosystems)** | **83** |
